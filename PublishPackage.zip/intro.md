nBold Connector
Overview
The nBold connector lets you build automation with teams, channels, sites, planners, and more to streamline collaboration and enhance governance of your collaboration environment. nBold enables you to create team templates with channels, file templates, folder structures, planner boards, and more, while automating team creation from templates at scale.
Features

Create Teams from Template: Create new teams with channels, files, folders, planners, lists, and more.
Approve or Reject Team Requests: Approve or reject team creation requests.
Manage Teams: Retrieve team details, archive teams, and access collaboration templates.
Security & Compliance: Ensure proper governance and compliance across Microsoft Teams.

Prerequisites
You will need the following:

A Microsoft Power Apps or Power Automate premium plan for one account only.
A valid trial or paid subscription to nBold.
nBold installed and connected to your tenant.

Authentication
This connector requires OAuth authentication. To obtain credentials:

Go to the connector and sign in.
Grant consent to the app.
Verify that everything is working.

Operations
Triggers

When a Team Creation Approval is Requested: Triggers when a team creation approval request is submitted.
When a Team Creation is Approved: Triggers when a team creation request is approved.
When a Team Creation is Rejected: Triggers when a team creation request is rejected.
When a Team is Created Using a Collaboration Template: Triggers when a team is successfully created from a collaboration template.

Actions

Create a Team Based on a Collaboration Template: Creates a new team using a predefined collaboration template.
Retrieve Templates: Fetches a list of available collaboration templates.
Get Team Details: Retrieves details of a specific team.
Archive a Team: Archives a team to restrict activity.
Unarchive a Team: Restores an archived team to active status.
Invite a Member in a Team: Adds a new member to a specified team.
Get the Channels of a Team: Retrieves all channels within a team.
Create a Channel in a Team: Creates a new channel in a specified team.
Get the Primary Channel of a Team: Fetches the default primary channel of a team.
Create a Tab in a Team Channel: Adds a tab to a specific channel in a team.
Copy a Channel in a Team: Creates a copy of a specified channel from a source team to a target team, including optional Salesforce and Cuddy Brain configurations.

For more details, visit nBold API Documentation.

